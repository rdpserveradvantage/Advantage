

<script>
     $(document).ready(function () {
        $("table").addClass("table-xs");
    });
</script>
<script type="text/javascript" src="files/bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="files/bower_components/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="files/bower_components/popper.js/dist/umd/popper.min.js"></script>
<script type="text/javascript" src="files/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

<script type="text/javascript" src="files/bower_components/jquery-slimscroll/jquery.slimscroll.js"></script>

<script type="text/javascript" src="files/bower_components/modernizr/modernizr.js"></script>
<script type="text/javascript" src="files/bower_components/modernizr/feature-detects/css-scrollbars.js"></script>

<script type="text/javascript" src="files/bower_components/chart.js/dist/Chart.js"></script>

<script src="files/assets/pages/widget/amchart/amcharts.js"></script>
<script src="files/assets/pages/widget/amchart/serial.js"></script>
<script src="files/assets/pages/widget/amchart/light.js"></script>

<script src="files/assets/js/pcoded.min.js"></script>
<script src="files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="files/assets/js/vartical-layout.min.js"></script>
<!--<script type="text/javascript" src="files/assets/pages/dashboard/analytic-dashboard.min.js"></script>-->
</body>
</html>