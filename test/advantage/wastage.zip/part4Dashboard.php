<?php include('config.php'); 

$totalPendingInstallation = array();
$categories = array();
$i=1 ; 
$sql = mysqli_query($con, "SELECT vendor, count(1) as totalSites FROM `projectInstallation` where status=1 and isDone=0 group by vendor");
while ($sql_result = mysqli_fetch_assoc($sql)) {
    $vendor = $sql_result['vendor'];
    $vendorName = getVendorName($vendor);
    $totalSites = (int)$sql_result['totalSites']; // Convert to integer

if($i==1){
    $totalPendingInstallation[] = array('name' => $vendorName, 'y' => $totalSites,true,true);
}else{
    $totalPendingInstallation[] = array('name' => $vendorName, 'y' => $totalSites,false);
}

    $categories[] = $vendorName;

$i++ ; 
    
}

?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<div class="col-sm-12">
    <div class="card">
        <div class="card-block">
            <div id="container" style="min-width: 300px; height: 300px; margin: 0 auto"></div>
        </div>
    </div>
</div>

<!--<script src="https://code.highcharts.com/modules/exporting.js"></script>-->
<script>
    var chartData = <?php echo json_encode($totalPendingInstallation, JSON_NUMERIC_CHECK); ?>;
    Highcharts.chart('container', {
        title: {
            text: 'Pending Installations'
        },
        xAxis: {
            categories: <?php echo json_encode($categories); ?>
        },
        series: [{
            type: 'pie',
            allowPointSelect: true,
            keys: ['name', 'y', 'selected', 'sliced'],
            data: chartData,
            showInLegend: true
        }],
        credits: {
            enabled: false
        },
        tooltip: {
            pointFormat: '<b>{point.name}</b>: {point.y}'
        }
    });

</script>
