<?php
// Retrieve form data
$serializedData = $_POST['data'];




var_dump($_REQUEST);
// Process the data as needed

// Send a response (optional)
$response = "Data received successfully.";
echo $response;
?>
